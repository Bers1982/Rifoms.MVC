<%@ Page Language="C#" Inherits="CuteEditor.EditorUtilityPage" %>
<script runat="server">
string GetDialogQueryString;
override protected void OnInit(EventArgs args)
{
	if(Context.Request.QueryString["Dialog"]=="Standard")
	{	
	if(Context.Request.QueryString["IsFrame"]==null)
	{
		string FrameSrc="colorpicker_basic.aspx?IsFrame=1&"+Request.ServerVariables["QUERY_STRING"];
		CuteEditor.CEU.WriteDialogOuterFrame(Context,"[[MoreColors]]",FrameSrc);
		Context.Response.End();
	}
	}
	string s="";
	if(Context.Request.QueryString["Dialog"]=="Standard")	
		s="&Dialog=Standard";
	
	GetDialogQueryString="Theme="+Context.Request.QueryString["Theme"]+s;	
	base.OnInit(args);
}
</script>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head runat="server">
		<meta http-equiv="Page-Enter" content="blendTrans(Duration=0.1)" />
		<meta http-equiv="Page-Exit" content="blendTrans(Duration=0.1)" />
		<script type="text/javascript" src="Load.ashx?type=dialogscript&verfix=1006&file=DialogHead.js"></script>
		<script type="text/javascript" src="Load.ashx?type=dialogscript&verfix=1006&file=Dialog_ColorPicker.js"></script>
		<link href='Load.ashx?type=themecss&file=dialog.css&theme=[[_Theme_]]' type="text/css"
			rel="stylesheet" />
		<style type="text/css">
			.colorcell
			{
				width:16px;
				height:17px;
				cursor:hand;
			}
			.colordiv,.customdiv
			{
				border:solid 1px #808080;
				width:16px;
				height:17px;
				font-size:1px;
			}
			#ajaxdiv{padding:10px;margin:0;text-align:center; background:#eeeeee;}
		</style>
		<title>[[NamedColors]]</title>
		<script>
								
		var OxOd541=["Green","#008000","Lime","#00FF00","Teal","#008080","Aqua","#00FFFF","Navy","#000080","Blue","#0000FF","Purple","#800080","Fuchsia","#FF00FF","Maroon","#800000","Red","#FF0000","Olive","#808000","Yellow","#FFFF00","White","#FFFFFF","Silver","#C0C0C0","Gray","#808080","Black","#000000","DarkOliveGreen","#556B2F","DarkGreen","#006400","DarkSlateGray","#2F4F4F","SlateGray","#708090","DarkBlue","#00008B","MidnightBlue","#191970","Indigo","#4B0082","DarkMagenta","#8B008B","Brown","#A52A2A","DarkRed","#8B0000","Sienna","#A0522D","SaddleBrown","#8B4513","DarkGoldenrod","#B8860B","Beige","#F5F5DC","HoneyDew","#F0FFF0","DimGray","#696969","OliveDrab","#6B8E23","ForestGreen","#228B22","DarkCyan","#008B8B","LightSlateGray","#778899","MediumBlue","#0000CD","DarkSlateBlue","#483D8B","DarkViolet","#9400D3","MediumVioletRed","#C71585","IndianRed","#CD5C5C","Firebrick","#B22222","Chocolate","#D2691E","Peru","#CD853F","Goldenrod","#DAA520","LightGoldenrodYellow","#FAFAD2","MintCream","#F5FFFA","DarkGray","#A9A9A9","YellowGreen","#9ACD32","SeaGreen","#2E8B57","CadetBlue","#5F9EA0","SteelBlue","#4682B4","RoyalBlue","#4169E1","BlueViolet","#8A2BE2","DarkOrchid","#9932CC","DeepPink","#FF1493","RosyBrown","#BC8F8F","Crimson","#DC143C","DarkOrange","#FF8C00","BurlyWood","#DEB887","DarkKhaki","#BDB76B","LightYellow","#FFFFE0","Azure","#F0FFFF","LightGray","#D3D3D3","LawnGreen","#7CFC00","MediumSeaGreen","#3CB371","LightSeaGreen","#20B2AA","DeepSkyBlue","#00BFFF","DodgerBlue","#1E90FF","SlateBlue","#6A5ACD","MediumOrchid","#BA55D3","PaleVioletRed","#DB7093","Salmon","#FA8072","OrangeRed","#FF4500","SandyBrown","#F4A460","Tan","#D2B48C","Gold","#FFD700","Ivory","#FFFFF0","GhostWhite","#F8F8FF","Gainsboro","#DCDCDC","Chartreuse","#7FFF00","LimeGreen","#32CD32","MediumAquamarine","#66CDAA","DarkTurquoise","#00CED1","CornflowerBlue","#6495ED","MediumSlateBlue","#7B68EE","Orchid","#DA70D6","HotPink","#FF69B4","LightCoral","#F08080","Tomato","#FF6347","Orange","#FFA500","Bisque","#FFE4C4","Khaki","#F0E68C","Cornsilk","#FFF8DC","Linen","#FAF0E6","WhiteSmoke","#F5F5F5","GreenYellow","#ADFF2F","DarkSeaGreen","#8FBC8B","Turquoise","#40E0D0","MediumTurquoise","#48D1CC","SkyBlue","#87CEEB","MediumPurple","#9370DB","Violet","#EE82EE","LightPink","#FFB6C1","DarkSalmon","#E9967A","Coral","#FF7F50","NavajoWhite","#FFDEAD","BlanchedAlmond","#FFEBCD","PaleGoldenrod","#EEE8AA","Oldlace","#FDF5E6","Seashell","#FFF5EE","PaleGreen","#98FB98","SpringGreen","#00FF7F","Aquamarine","#7FFFD4","PowderBlue","#B0E0E6","LightSkyBlue","#87CEFA","LightSteelBlue","#B0C4DE","Plum","#DDA0DD","Pink","#FFC0CB","LightSalmon","#FFA07A","Wheat","#F5DEB3","Moccasin","#FFE4B5","AntiqueWhite","#FAEBD7","LemonChiffon","#FFFACD","FloralWhite","#FFFAF0","Snow","#FFFAFA","AliceBlue","#F0F8FF","LightGreen","#90EE90","MediumSpringGreen","#00FA9A","PaleTurquoise","#AFEEEE","LightCyan","#E0FFFF","LightBlue","#ADD8E6","Lavender","#E6E6FA","Thistle","#D8BFD8","MistyRose","#FFE4E1","Peachpuff","#FFDAB9","PapayaWhip","#FFEFD5"];var colorlist=[{n:OxOd541[0],h:OxOd541[1]},{n:OxOd541[2],h:OxOd541[3]},{n:OxOd541[4],h:OxOd541[5]},{n:OxOd541[6],h:OxOd541[7]},{n:OxOd541[8],h:OxOd541[9]},{n:OxOd541[10],h:OxOd541[11]},{n:OxOd541[12],h:OxOd541[13]},{n:OxOd541[14],h:OxOd541[15]},{n:OxOd541[16],h:OxOd541[17]},{n:OxOd541[18],h:OxOd541[19]},{n:OxOd541[20],h:OxOd541[21]},{n:OxOd541[22],h:OxOd541[23]},{n:OxOd541[24],h:OxOd541[25]},{n:OxOd541[26],h:OxOd541[27]},{n:OxOd541[28],h:OxOd541[29]},{n:OxOd541[30],h:OxOd541[31]}];var colormore=[{n:OxOd541[32],h:OxOd541[33]},{n:OxOd541[34],h:OxOd541[35]},{n:OxOd541[36],h:OxOd541[37]},{n:OxOd541[38],h:OxOd541[39]},{n:OxOd541[40],h:OxOd541[41]},{n:OxOd541[42],h:OxOd541[43]},{n:OxOd541[44],h:OxOd541[45]},{n:OxOd541[46],h:OxOd541[47]},{n:OxOd541[48],h:OxOd541[49]},{n:OxOd541[50],h:OxOd541[51]},{n:OxOd541[52],h:OxOd541[53]},{n:OxOd541[54],h:OxOd541[55]},{n:OxOd541[56],h:OxOd541[57]},{n:OxOd541[58],h:OxOd541[59]},{n:OxOd541[60],h:OxOd541[61]},{n:OxOd541[62],h:OxOd541[63]},{n:OxOd541[64],h:OxOd541[65]},{n:OxOd541[66],h:OxOd541[67]},{n:OxOd541[68],h:OxOd541[69]},{n:OxOd541[70],h:OxOd541[71]},{n:OxOd541[72],h:OxOd541[73]},{n:OxOd541[74],h:OxOd541[75]},{n:OxOd541[76],h:OxOd541[77]},{n:OxOd541[78],h:OxOd541[79]},{n:OxOd541[80],h:OxOd541[81]},{n:OxOd541[82],h:OxOd541[83]},{n:OxOd541[84],h:OxOd541[85]},{n:OxOd541[86],h:OxOd541[87]},{n:OxOd541[88],h:OxOd541[89]},{n:OxOd541[90],h:OxOd541[91]},{n:OxOd541[92],h:OxOd541[93]},{n:OxOd541[94],h:OxOd541[95]},{n:OxOd541[96],h:OxOd541[97]},{n:OxOd541[98],h:OxOd541[99]},{n:OxOd541[100],h:OxOd541[101]},{n:OxOd541[102],h:OxOd541[103]},{n:OxOd541[104],h:OxOd541[105]},{n:OxOd541[106],h:OxOd541[107]},{n:OxOd541[108],h:OxOd541[109]},{n:OxOd541[110],h:OxOd541[111]},{n:OxOd541[112],h:OxOd541[113]},{n:OxOd541[114],h:OxOd541[115]},{n:OxOd541[116],h:OxOd541[117]},{n:OxOd541[118],h:OxOd541[119]},{n:OxOd541[120],h:OxOd541[121]},{n:OxOd541[122],h:OxOd541[123]},{n:OxOd541[124],h:OxOd541[125]},{n:OxOd541[126],h:OxOd541[127]},{n:OxOd541[128],h:OxOd541[129]},{n:OxOd541[130],h:OxOd541[131]},{n:OxOd541[132],h:OxOd541[133]},{n:OxOd541[134],h:OxOd541[135]},{n:OxOd541[136],h:OxOd541[137]},{n:OxOd541[138],h:OxOd541[139]},{n:OxOd541[140],h:OxOd541[141]},{n:OxOd541[142],h:OxOd541[143]},{n:OxOd541[144],h:OxOd541[145]},{n:OxOd541[146],h:OxOd541[147]},{n:OxOd541[148],h:OxOd541[149]},{n:OxOd541[150],h:OxOd541[151]},{n:OxOd541[152],h:OxOd541[153]},{n:OxOd541[154],h:OxOd541[155]},{n:OxOd541[156],h:OxOd541[157]},{n:OxOd541[158],h:OxOd541[159]},{n:OxOd541[160],h:OxOd541[161]},{n:OxOd541[162],h:OxOd541[163]},{n:OxOd541[164],h:OxOd541[165]},{n:OxOd541[166],h:OxOd541[167]},{n:OxOd541[168],h:OxOd541[169]},{n:OxOd541[170],h:OxOd541[171]},{n:OxOd541[172],h:OxOd541[173]},{n:OxOd541[174],h:OxOd541[175]},{n:OxOd541[176],h:OxOd541[177]},{n:OxOd541[178],h:OxOd541[179]},{n:OxOd541[180],h:OxOd541[181]},{n:OxOd541[182],h:OxOd541[183]},{n:OxOd541[184],h:OxOd541[185]},{n:OxOd541[186],h:OxOd541[187]},{n:OxOd541[188],h:OxOd541[189]},{n:OxOd541[190],h:OxOd541[191]},{n:OxOd541[192],h:OxOd541[193]},{n:OxOd541[194],h:OxOd541[195]},{n:OxOd541[196],h:OxOd541[197]},{n:OxOd541[198],h:OxOd541[199]},{n:OxOd541[200],h:OxOd541[201]},{n:OxOd541[202],h:OxOd541[203]},{n:OxOd541[204],h:OxOd541[205]},{n:OxOd541[206],h:OxOd541[207]},{n:OxOd541[208],h:OxOd541[209]},{n:OxOd541[210],h:OxOd541[211]},{n:OxOd541[212],h:OxOd541[213]},{n:OxOd541[214],h:OxOd541[215]},{n:OxOd541[216],h:OxOd541[217]},{n:OxOd541[218],h:OxOd541[219]},{n:OxOd541[220],h:OxOd541[221]},{n:OxOd541[156],h:OxOd541[157]},{n:OxOd541[222],h:OxOd541[223]},{n:OxOd541[224],h:OxOd541[225]},{n:OxOd541[226],h:OxOd541[227]},{n:OxOd541[228],h:OxOd541[229]},{n:OxOd541[230],h:OxOd541[231]},{n:OxOd541[232],h:OxOd541[233]},{n:OxOd541[234],h:OxOd541[235]},{n:OxOd541[236],h:OxOd541[237]},{n:OxOd541[238],h:OxOd541[239]},{n:OxOd541[240],h:OxOd541[241]},{n:OxOd541[242],h:OxOd541[243]},{n:OxOd541[244],h:OxOd541[245]},{n:OxOd541[246],h:OxOd541[247]},{n:OxOd541[248],h:OxOd541[249]},{n:OxOd541[250],h:OxOd541[251]},{n:OxOd541[252],h:OxOd541[253]},{n:OxOd541[254],h:OxOd541[255]},{n:OxOd541[256],h:OxOd541[257]},{n:OxOd541[258],h:OxOd541[259]},{n:OxOd541[260],h:OxOd541[261]},{n:OxOd541[262],h:OxOd541[263]},{n:OxOd541[264],h:OxOd541[265]},{n:OxOd541[266],h:OxOd541[267]},{n:OxOd541[268],h:OxOd541[269]},{n:OxOd541[270],h:OxOd541[271]},{n:OxOd541[272],h:OxOd541[273]}];
		
		</script>
	</head>
	<body>
		<div id="ajaxdiv">
			<div class="tab-pane-control tab-pane" id="tabPane1">
				<div class="tab-row">
					<h2 class="tab">
						<a tabindex="-1" href='colorpicker.aspx?<%=GetDialogQueryString%>'>
							<span style="white-space:nowrap;">
								[[WebPalette]]
							</span>
						</a>
					</h2>
					<h2 class="tab selected">
							<a tabindex="-1" href='colorpicker_basic.aspx?<%=GetDialogQueryString%>'>
								<span style="white-space:nowrap;">
									[[NamedColors]]
								</span>
							</a>
					</h2>
					<h2 class="tab">
							<a tabindex="-1" href='colorpicker_more.aspx?<%=GetDialogQueryString%>'>
								<span style="white-space:nowrap;">
									[[CustomColor]]
								</span>
							</a>
					</h2>
				</div>
				<div class="tab-page">			
					<table class="colortable" align="center">
						<tr>
							<td colspan="16" height="16"><p align="left">Basic:
								</p>
							</td>
						</tr>
						<tr>
							<script>
								var OxOfde8=["length","\x3Ctd class=\x27colorcell\x27\x3E\x3Cdiv class=\x27colordiv\x27 style=\x27background-color:","\x27 title=\x27"," ","\x27 cname=\x27","\x27 cvalue=\x27","\x27\x3E\x3C/div\x3E\x3C/td\x3E",""];var arr=[];for(var i=0;i<colorlist[OxOfde8[0]];i++){arr.push(OxOfde8[1]);arr.push(colorlist[i].n);arr.push(OxOfde8[2]);arr.push(colorlist[i].n);arr.push(OxOfde8[3]);arr.push(colorlist[i].h);arr.push(OxOfde8[4]);arr.push(colorlist[i].n);arr.push(OxOfde8[5]);arr.push(colorlist[i].h);arr.push(OxOfde8[6]);} ;document.write(arr.join(OxOfde8[7]));
							</script>
						</tr>
						<tr>
							<td colspan="16" height="12"><p align="left"></p>
							</td>
						</tr>
						<tr>
							<td colspan="16"><p align="left">Additional:
								</p>
							</td>
						</tr>
						<script>
							var OxOcfac=["length","\x3Ctr\x3E","\x3Ctd class=\x27colorcell\x27\x3E\x3Cdiv class=\x27colordiv\x27 style=\x27background-color:","\x27 title=\x27"," ","\x27 cname=\x27","\x27 cvalue=\x27","\x27\x3E\x3C/div\x3E\x3C/td\x3E","\x3C/tr\x3E",""];var arr=[];for(var i=0;i<colormore[OxOcfac[0]];i++){if(i%16==0){arr.push(OxOcfac[1]);} ;arr.push(OxOcfac[2]);arr.push(colormore[i].n);arr.push(OxOcfac[3]);arr.push(colormore[i].n);arr.push(OxOcfac[4]);arr.push(colormore[i].h);arr.push(OxOcfac[5]);arr.push(colormore[i].n);arr.push(OxOcfac[6]);arr.push(colormore[i].h);arr.push(OxOcfac[7]);if(i%16==15){arr.push(OxOcfac[8]);} ;} ;if(colormore%16>0){arr.push(OxOcfac[8]);} ;document.write(arr.join(OxOcfac[9]));
						</script>
						<tr>
							<td colspan="16" height="8">
							</td>
						</tr>
						<tr>
							<td colspan="16" height="12">
								<input checked id="CheckboxColorNames" style="width: 16px; height: 20px" type="checkbox">
								<span style="width: 118px;">Use color names</span>
							</td>
						</tr>
						<tr>
							<td colspan="16" height="12">
							</td>
						</tr>
						<tr>
							<td colspan="16" valign="middle" height="24">
							<span style="height:24px;width:50px;vertical-align:middle;">Color : </span>&nbsp;
							<input type="text" id="divpreview" size="7" maxlength="7" style="width:180px;height:24px;border:#a0a0a0 1px solid; Padding:4;"/>
					
							</td>
						</tr>
				</table>
			</div>
		</div>
		<div id="container-bottom">
			<input type="button" id="buttonok" value="[[OK]]" class="formbutton" style="width:70px"	onclick="do_insert();" /> 
			&nbsp;&nbsp;&nbsp;&nbsp; 
			<input type="button" id="buttoncancel" value="[[Cancel]]" class="formbutton" style="width:70px"	onclick="do_Close();" />	
		</div>
	</div>
	</body>
</html>

