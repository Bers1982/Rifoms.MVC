<%@ Control Inherits="CuteEditor.EditorUtilityCtrl" Language="c#" AutoEventWireup="false" TargetSchema="http://schemas.microsoft.com/intellisense/ie5" %>
<div id="outer"><div id="div_demo">[[DemoText]]</div></div>
<script type="text/javascript">

var OxOd5db=["cssText","style"];function UpdateState(){div_demo[OxOd5db[1]][OxOd5db[0]]=element[OxOd5db[1]][OxOd5db[0]];} ;function SyncToView(){} ;function SyncTo(element){} ;

</script>
